export class Student {

    cno!:number;
    name!:String;
    email!:String;
    password!:String;
    div!:String;
    branch!:String;
    academicYear!:String;
    mobileno!:String;

}