export class Events {

    cno!:String;
    eventname!:String ;
    oragnizer!:String ;
    category!:String ;
    level!:String ;
    doe!:String ;
    participation_status!:String ;
}

